package service;

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import main.stopwatch;

public class error {
	public static void errorReport(Exception e){
		Dialog d = new Dialog(main.stopwatch.f ,"STOP! ENGINE ERROR", true);
		d.setSize(380, 170);
		
		String error = e.getMessage();
		d.add(new Label(error), "North");
		
		d.setLocation(stopwatch.displaySetX, stopwatch.displaySetY); //ȭ�� ��ġ ����.
		d.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e){
				System.exit(0);
			}
		}); //â�� ���� �� �ֵ��� ����.
		
		d.setVisible(true);
	}
}
