package service;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class startWatch implements ActionListener {
	public void main(){
		main.item.timerH.setText(" " + setupTime.hour + " : " + setupTime.min);
		main.item.timerS.setText(" " + setupTime.sec + "");
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		long secOFhour = setupTime.hour * 3600;
		long secOFmin = setupTime.min * 60;
		long secOFsec = setupTime.sec;
		
		long allTime = secOFhour + secOFmin + secOFsec;
		
		engine.timerEngine engine = new engine.timerEngine(allTime);
		engine.start();
		
		main.item.setTime.setVisible(false);
		main.item.startTimer.setVisible(false);
	}
}
