package service;

public class setupTime {
	public static int hour = 0;
	public static int min = 0;
	public static int sec = 0;
}
