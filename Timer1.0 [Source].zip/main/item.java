package main;
import main.stopwatch;
import java.awt.*;
import main.event;

public class item extends main.event{
	static private Font font = new Font("����", Font.BOLD, 40);
	public static Label timerH = null;
	public static Label timerS = null;
	
	public static Button setTime = null;
	public static Button startTimer = null;
	
	public void timerHM(){
		timerH = new Label("  00 : 00 ");
		timerH.setFont(font);
		stopwatch.f.add(timerH);
	}
	
	public void timerSM(){
		timerS = new Label("  00");
		timerS.setFont(font);
		stopwatch.f.add(timerS);
	}
	
	public void timeSetBtn(){
		 setTime  = new Button("�ð� ���� (Set time)");
		event setTimeEvent = new event();
		
		setTime.addActionListener(setTimeEvent);
		stopwatch.f.add(setTime);
	}
	
	public void startBtn(){
		startTimer  = new Button("���� (Start)");
		service.startWatch startStopWatch = new service.startWatch();
		startTimer.addActionListener(startStopWatch);
		stopwatch.f.add(startTimer);
	}
}
