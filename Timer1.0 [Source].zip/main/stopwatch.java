package main;

import java.awt.*;
import java.awt.event.*;

public class stopwatch {
	public static int displaySetX = 0;
	public static int displaySetY = 0;
	public static Frame f = null;

	public static void main(String[] args) {
		f = new Frame("StopWatch 1.0");
		f.setSize(350,170);
		displaySetX = (int) ((f.getWidth() / 2));
		displaySetY = (int) ((f.getWidth() / 2));
		
		f.setLocation(displaySetX, displaySetY); //ȭ�� ��ġ ����.
		f.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e){
				System.exit(0);
			}
		}); //â�� ���� �� �ֵ��� ����.
		f.setLayout(new GridLayout(2,2));
		
		item setTimer = new item();
		setTimer.timerHM();
		setTimer.timerSM();
		setTimer.timeSetBtn();
		setTimer.startBtn();
		
		
		f.setVisible(true);
		
	}

}
