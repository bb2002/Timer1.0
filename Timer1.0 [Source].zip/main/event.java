package main;

import java.awt.*;
import java.awt.event.*;

public class event implements ActionListener{
	public static TextField hour = null;
	public static TextField min = null;
	public static TextField sec = null;
	public static Dialog d = null;

	@Override
	public void actionPerformed(ActionEvent ae) {
		d = new Dialog(stopwatch.f, "Setting time. �ð�����.", true);
		d.setLocation(stopwatch.displaySetX, stopwatch.displaySetY);
		d.setSize(350, 170);
		
		d.setLocation(stopwatch.displaySetX, stopwatch.displaySetY); //ȭ�� ��ġ ����.
		d.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e){
				d.setVisible(false);
			}
		}); //â�� ���� �� �ֵ��� ����.
		
		d.setLayout(new BorderLayout());
		
		hour = new TextField(2);
		min = new TextField(2);
		sec = new TextField(2);
		Label colone = new Label(":");
		
		Panel setTime = new Panel();
		
		setTime.setLayout(new FlowLayout());
		setTime.add(hour);
		setTime.add(new Label(":"));
		setTime.add(min);
		setTime.add(colone);
		setTime.add(sec);
		
		d.add(setTime, "North");
		Button setTimeBtn = new Button("���� �Ϸ�");
		engine.timeSet engineTimer= new engine.timeSet();
		setTimeBtn.addActionListener(engineTimer);
		
		
		d.add(setTimeBtn, "Center");
		
		d.setVisible(true);
	}
	
}
