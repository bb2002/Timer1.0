package engine;


public class timerEngine extends Thread{
	private static long allTime = 0;
	private static String hourText = null;
	private static String minText = null;
	private static String secText = null;
	
	@SuppressWarnings("static-access")
	public timerEngine(long allTime) {
		this.allTime = allTime;
	}


	@SuppressWarnings("static-access")
	public void run(){
		this.allTime = service.setupTime.hour * 3600;
		this.allTime += service.setupTime.min * 60;
		this.allTime += service.setupTime.sec;
		System.out.println(allTime);
		
		while(true){
			
			this.allTime -= 1;
			
			//�ú��� �� ȯ��ó��
			if(this.allTime >= 3600){
				service.setupTime.hour = (int) (this.allTime / 3600);
				System.out.println(service.setupTime.hour);
			}
			
			if(this.allTime - service.setupTime.hour * 3600 >= 60){
				int temp = (int) (this.allTime - (service.setupTime.hour * 3600));
				service.setupTime.min = (int) temp / 60;
			}
			
			if((int)this.allTime - ((service.setupTime.hour * 3600) + (service.setupTime.min * 60)) == 0){
				if(service.setupTime.min != 0){
					service.setupTime.min -= 1;
					service.setupTime.sec = 0;
				} else if(service.setupTime.hour != 0){
					service.setupTime.hour -= 1;
					service.setupTime.min = 59;
					service.setupTime.sec -= 0;
				} else {
					System.out.println("�ð� �ى��.");
				}
			} else {
				service.setupTime.sec = (int)this.allTime - ((service.setupTime.hour * 3600) + (service.setupTime.min * 60));
			}
			
			
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

			this.updateTimer();
			
			if(this.allTime == 1 || this.allTime < 1){
				break;
			}
		}
		
		main.item mm = new main.item();
		mm.timerH.setText(" " + "00" + " : " + "00" + " ");
		mm.timerS.setText("  " + "00" + "s");
		
		engine.endTimer end = new engine.endTimer();
		end.main();	
	}
	
	@SuppressWarnings("static-access")
	public void updateTimer(){
		main.item mm = new main.item();
		
		if(service.setupTime.hour < 10){
			//0�� �տ� ���Դϴ�.
			hourText = " 0" + service.setupTime.hour;
		} else {
			hourText = "" + service.setupTime.hour;
		}
		
		if(service.setupTime.min < 10){
			//0�� �տ� ���Դϴ�.
			minText = " 0" + service.setupTime.min;
		} else {
			minText = "" + service.setupTime.min;
		}
		
		if(service.setupTime.sec < 10){
			//0�� �տ� ���Դϴ�.
			secText = " 0" + service.setupTime.sec;
		} else {
			secText = "" + service.setupTime.sec;
		}
		System.out.print(hourText + " ");
		System.out.print(minText + " ");
		System.out.print(secText + " ");
		
		mm.timerH.setText(" " + hourText + " : " + minText + " ");
		mm.timerS.setText("  " + secText + "s");
	}
}
