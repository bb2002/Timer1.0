package engine;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class timeSet implements ActionListener{

	@SuppressWarnings("static-access")
	@Override
	public void actionPerformed(ActionEvent e) {
		main.event items = new main.event();
		String hour = items.hour.getText();
		if(hour.equals("")){
			hour = "00";
		}
		
		String min = items.min.getText();
		if(min.equals("")){
			min = "00";
		}
		if(Integer.parseInt(min) >= 60){
			min = "59";
		}
		
		String sec = items.sec.getText();
		if(sec.equals("")){
			sec = "00";
		}
		if(Integer.parseInt(sec) >= 60){
			sec = "59";
		}
		
		try{
			service.setupTime.hour = Integer.parseInt(hour);
			service.setupTime.min = Integer.parseInt(min);
			service.setupTime.sec = Integer.parseInt(sec);
			
			main.event.d.setVisible(false);
		} catch(Exception e1){
			service.error.errorReport(e1); //����â ����
		}
		
		service.startWatch startMiner = new service.startWatch();
		startMiner.main();
	}
}
